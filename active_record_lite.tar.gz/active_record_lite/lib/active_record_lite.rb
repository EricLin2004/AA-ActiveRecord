# NR: Comment these back in as you write them.

#require_relative './active_record_lite/associatable'
require_relative './active_record_lite/db_connection'
#require_relative './active_record_lite/mass_object'
#require_relative './active_record_lite/searchable'
#require_relative './active_record_lite/sql_object'
